package com.example.androidexam.dao;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.androidexam.entity.Finance;

import java.util.ArrayList;
import java.util.List;

public class FinanceDAOImpl implements IFinanceDAO{
    private SQLiteDatabase mDB;

    public FinanceDAOImpl(Context ctx) {
        DatabaseHelper helper = new DatabaseHelper(ctx);
        mDB = helper.getWritableDatabase();
    }
    @Override
    public List<Finance> select() {
        String sql = "SELECT * FROM tblFinance";
        List<Finance> list = new ArrayList<>();
        Cursor c = mDB.rawQuery(sql, null);
        while (c.moveToNext()) {
            @SuppressLint("Range") int id = c.getInt(c.getColumnIndex("id"));
            @SuppressLint("Range") String name = c.getString(c.getColumnIndex("name"));
            @SuppressLint("Range") Double money = c.getDouble(c.getColumnIndex("money"));

            Finance f = new Finance(id, name, money);
            list.add(f);
        }
        return list;
    }

    @Override
    public Finance selectById(int id) {
        String sql = "SELECT * FROM tblFinance WHERE id = ?";
        Cursor c = mDB.rawQuery(sql, new String[]{String.valueOf(id)});
        while (c.moveToNext()) {
            @SuppressLint("Range") String name = c.getString(c.getColumnIndex("name"));
            @SuppressLint("Range") Double money = c.getDouble(c.getColumnIndex("money"));


            Finance f = new Finance(id, name, money);
            return f;
        }
        return null;
    }

    @Override
    public boolean update(Finance f) {
        ContentValues cv = new ContentValues();
        cv.put("name", f.getName());
        cv.put("money", f.getMoney());
        long newId = mDB.update("tblFinance", cv, " id = " + f.getId(), null);
        return newId > 0;
    }

    @Override
    public boolean delete(int id) {
        long newId = mDB.delete("tblFinance", "id =" + id, null);
        return newId > 0;
    }
}
