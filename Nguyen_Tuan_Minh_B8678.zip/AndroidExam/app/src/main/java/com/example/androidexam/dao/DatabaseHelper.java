package com.example.androidexam.dao;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "finance.sqlite";
    private static final int DATABASE_VERSION = 1;

    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE tblFinance (\n" +
                "    id       INTEGER       PRIMARY KEY AUTOINCREMENT,\n" +
                "    name STRING            NOT NULL,\n" +
                "    money DOUBLE        NOT NULL,\n" +
                "    CHECK(money >= 0)" +
                ");\n";
        db.execSQL(sql);

        sql = "INSERT INTO tblFinance(name, money) VALUES ('Mua quần áo', 125000)";
        db.execSQL(sql);
        sql = "INSERT INTO tblFinance(name, money) VALUES ('Ăn sáng', 10000)";
        db.execSQL(sql);
        sql = "INSERT INTO tblFinance(name, money) VALUES ('Ăn trưa', 25000)";
        db.execSQL(sql);
        sql = "INSERT INTO tblFinance(name, money) VALUES ('Đưa gấu đi chơi', 312800)";
        db.execSQL(sql);
        sql = "INSERT INTO tblFinance(name, money) VALUES ('Nạp điện thoại', 5000)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
