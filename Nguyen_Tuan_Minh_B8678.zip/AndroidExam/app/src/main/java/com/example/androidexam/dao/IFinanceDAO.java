package com.example.androidexam.dao;

import com.example.androidexam.entity.Finance;

import java.util.List;

public interface IFinanceDAO {
    public List<Finance> select();
    public Finance selectById(int id);
    public boolean update(Finance f);
    public boolean delete(int id);
}
