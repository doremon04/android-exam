package com.example.androidexam.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.androidexam.R;
import com.example.androidexam.entity.Finance;

import java.util.List;

public class AdapterFinance extends ArrayAdapter<Finance> {
    private final Context mCtx;
    private final List<Finance> mList;

    public AdapterFinance(@NonNull Context context, @NonNull List<Finance> objects) {
        super(context, R.layout.item_finance, objects);
        this.mCtx = context;
        this.mList = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            v = LayoutInflater.from(this.mCtx).inflate(R.layout.item_finance, null);
        }
        Finance f = mList.get(position);
        TextView txtName = v.findViewById(R.id.txtName);
        TextView txtMoney = v.findViewById(R.id.txtMoney);

        txtName.setText(f.getName());
        txtMoney.setText("đ" + f.getMoney());
        return v;
    }
}
