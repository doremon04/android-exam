package com.example.androidexam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;

import com.example.androidexam.adapter.AdapterFinance;
import com.example.androidexam.dao.FinanceDAOImpl;
import com.example.androidexam.dao.IFinanceDAO;
import com.example.androidexam.databinding.ActivityMainBinding;
import com.example.androidexam.entity.Finance;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private List<Finance> lst;
    private ActivityMainBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        loadFinance();
    }

    private void loadFinance() {
        IFinanceDAO financeDAO = new FinanceDAOImpl(this);
        lst = financeDAO.select();

        AdapterFinance adapterFinance = new AdapterFinance(this, lst);
        binding.listFinance.setAdapter(adapterFinance);

        binding.listFinance.setOnItemClickListener((adapterView, view, pos, l) -> {
            Intent intent = new Intent(this, FinanceActivity.class);
            int id = lst.get(pos).getId();
            intent.putExtra("ids", id);
            startActivity(intent);
        });

        registerForContextMenu(binding.listFinance);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
}