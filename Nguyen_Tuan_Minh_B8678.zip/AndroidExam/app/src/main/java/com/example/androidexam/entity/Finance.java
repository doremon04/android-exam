package com.example.androidexam.entity;

public class Finance {
    public int id;
    public String name;
    public double money;

    public Finance(int id, String name, double money) {
        this.id = id;
        this.name = name;
        this.money = money;
    }

    public Finance(String name, double money) {
        this.name = name;
        this.money = money;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }
}
